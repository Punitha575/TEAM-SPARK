"""MEDINOVA AI — Main Python Tkinter Desktop Application."""

from __future__ import annotations

import tkinter as tk
from tkinter import ttk

from services.gemini_service import SUPPORTED_LANGUAGES, MedinovaGeminiService
from services.profile_store import PatientProfile, ProfileStore
from ui.health_assistant import HealthAssistantFrame
from ui.medicine_guide import MedicineGuideFrame
from ui.patient_profile import PatientProfileFrame
from ui.pdf_analyzer import PDFAnalyzerFrame
from ui.symptom_checker import SymptomCheckerFrame
from ui.theme import FONTS, PALETTE, configure_ttk_styles


class MedinovaApp(tk.Tk):
    """Root Tkinter window coordinating all 5 MEDINOVA AI modules."""

    def __init__(self) -> None:
        super().__init__()
        self.title("MEDINOVA AI — Multilingual Healthcare Assistant")
        self.geometry("1160x780")
        self.minsize(960, 660)
        self.configure(bg=PALETTE["bg"])

        configure_ttk_styles(self)

        self.profile_store = ProfileStore()
        self.active_profile: PatientProfile = self.profile_store.load()
        self.gemini_service = MedinovaGeminiService()

        initial_lang = (
            self.active_profile.preferred_language
            if self.active_profile.preferred_language in SUPPORTED_LANGUAGES
            else "English"
        )
        self.language_var = tk.StringVar(value=initial_lang)
        self.include_profile_var = tk.BooleanVar(value=True)

        self._nav_buttons: dict[str, tk.Button] = {}
        self._frames: dict[str, ttk.Frame] = {}

        self._build_layout()
        self._show_module("symptom_checker")

    def _get_language(self) -> str:
        return self.language_var.get()

    def _get_patient_context(self) -> str:
        if not self.include_profile_var.get():
            return ""
        return self.active_profile.to_clinical_context()

    def _on_profile_saved(self, profile: PatientProfile) -> None:
        self.active_profile = profile
        if profile.preferred_language in SUPPORTED_LANGUAGES:
            self.language_var.set(profile.preferred_language)
        self._refresh_profile_badge()

    def _refresh_profile_badge(self) -> None:
        name = self.active_profile.full_name.strip() or "Guest Patient"
        self.patient_badge.configure(text=f"Active Profile: {name}")

    def _build_layout(self) -> None:
        # Left Sidebar Navigation
        sidebar = tk.Frame(self, bg=PALETTE["sidebar"], width=235)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)

        brand_box = tk.Frame(sidebar, bg=PALETTE["sidebar"], padx=18, pady=20)
        brand_box.pack(fill="x")
        tk.Label(
            brand_box,
            text="MEDINOVA AI",
            font=("Segoe UI", 16, "bold"),
            bg=PALETTE["sidebar"],
            fg="#FFFFFF",
        ).pack(anchor="w")
        tk.Label(
            brand_box,
            text="Clinical Education & Triage",
            font=("Segoe UI", 9),
            bg=PALETTE["sidebar"],
            fg="#94A3B8",
        ).pack(anchor="w", pady=(2, 0))

        nav_items = [
            ("patient_profile", "1. Patient Profile"),
            ("symptom_checker", "2. Symptom Checker"),
            ("medicine_guide", "3. Medicine Guide"),
            ("health_assistant", "4. AI Health Assistant"),
            ("pdf_analyzer", "5. Medical PDF Analyzer"),
        ]

        for key, label in nav_items:
            btn = tk.Button(
                sidebar,
                text=label,
                anchor="w",
                font=FONTS["body_bold"],
                bg=PALETTE["sidebar"],
                fg="#E2E8F0",
                activebackground=PALETTE["sidebar_hover"],
                activeforeground="#FFFFFF",
                bd=0,
                padx=18,
                pady=12,
                cursor="hand2",
                command=lambda k=key: self._show_module(k),
            )
            btn.pack(fill="x")
            self._nav_buttons[key] = btn

        # Bottom configuration notice in sidebar
        env_status = (
            "Gemini API Key: Loaded from Env"
            if self.gemini_service.is_configured()
            else "Gemini API Key: Missing in .env"
        )
        env_color = "#34D399" if self.gemini_service.is_configured() else "#FBBF24"
        footer = tk.Frame(sidebar, bg=PALETTE["sidebar"], padx=18, pady=16)
        footer.pack(side="bottom", fill="x")
        tk.Label(
            footer,
            text=env_status,
            font=("Segoe UI", 9, "bold"),
            bg=PALETTE["sidebar"],
            fg=env_color,
            wraplength=195,
            justify="left",
        ).pack(anchor="w")
        tk.Label(
            footer,
            text="Educational use only. Not a substitute for licensed medical care.",
            font=("Segoe UI", 8),
            bg=PALETTE["sidebar"],
            fg="#94A3B8",
            wraplength=195,
            justify="left",
        ).pack(anchor="w", pady=(6, 0))

        # Main Right Column
        right_col = tk.Frame(self, bg=PALETTE["bg"])
        right_col.pack(side="left", fill="both", expand=True)

        # Top Control Bar
        topbar = tk.Frame(
            right_col,
            bg=PALETTE["surface"],
            padx=20,
            pady=10,
            highlightbackground=PALETTE["border"],
            highlightthickness=1,
        )
        topbar.pack(fill="x")

        self.patient_badge = tk.Label(
            topbar,
            text="",
            font=FONTS["body_bold"],
            bg=PALETTE["surface"],
            fg=PALETTE["text"],
        )
        self.patient_badge.pack(side="left")
        self._refresh_profile_badge()

        # Right side controls in top bar
        tk.Checkbutton(
            topbar,
            text="Include Profile Context",
            variable=self.include_profile_var,
            bg=PALETTE["surface"],
            fg=PALETTE["text"],
            activebackground=PALETTE["surface"],
            font=FONTS["subtitle"],
        ).pack(side="right", padx=(16, 0))

        ttk.Combobox(
            topbar,
            textvariable=self.language_var,
            values=SUPPORTED_LANGUAGES,
            state="readonly",
            width=26,
        ).pack(side="right", padx=(6, 0))

        tk.Label(
            topbar,
            text="Response Language:",
            font=FONTS["body_bold"],
            bg=PALETTE["surface"],
            fg=PALETTE["text"],
        ).pack(side="right")

        # Content Stack
        self.content_area = tk.Frame(right_col, bg=PALETTE["bg"])
        self.content_area.pack(fill="both", expand=True)

        self._frames["patient_profile"] = PatientProfileFrame(
            self.content_area, self.profile_store, self._on_profile_saved
        )
        self._frames["symptom_checker"] = SymptomCheckerFrame(
            self.content_area,
            self.gemini_service,
            self._get_language,
            self._get_patient_context,
        )
        self._frames["medicine_guide"] = MedicineGuideFrame(
            self.content_area,
            self.gemini_service,
            self._get_language,
            self._get_patient_context,
        )
        self._frames["health_assistant"] = HealthAssistantFrame(
            self.content_area,
            self.gemini_service,
            self._get_language,
            self._get_patient_context,
        )
        self._frames["pdf_analyzer"] = PDFAnalyzerFrame(
            self.content_area,
            self.gemini_service,
            self._get_language,
            self._get_patient_context,
        )

    def _show_module(self, key: str) -> None:
        for frame in self._frames.values():
            frame.pack_forget()
        self._frames[key].pack(fill="both", expand=True)

        for nav_key, btn in self._nav_buttons.items():
            if nav_key == key:
                btn.configure(bg=PALETTE["sidebar_active"], fg="#FFFFFF")
            else:
                btn.configure(bg=PALETTE["sidebar"], fg="#E2E8F0")


if __name__ == "__main__":
    app = MedinovaApp()
    app.mainloop()
