# MEDINOVA AI (Python Tkinter + Google Gemini AI + PyMuPDF)

A complete, modular Python healthcare education desktop application featuring 5 integrated Tkinter modules:

1. **Patient Profile** (`ui/patient_profile.py`) — Saves baseline clinical details locally (`data/patient_profile.json`), auto-calculates BMI, and shares non-identifying context with AI modules.
2. **Symptom Checker** (`ui/symptom_checker.py`) — Provides general health information and possible causes (explicitly non-diagnostic) with emergency red-flag checks.
3. **Medicine Guide** (`ui/medicine_guide.py`) — Provides evidence-based medicine uses, precautions, side effects, and profile allergy/drug interaction checks.
4. **AI Health Assistant** (`ui/health_assistant.py`) — Multi-turn open-ended health Q&A powered by `google-genai` chat sessions.
5. **Medical PDF Analyzer** (`ui/pdf_analyzer.py`) — Extracts readable text from medical PDFs with PyMuPDF (`fitz`) and explains key findings with Gemini AI.

## Installation & Execution

```bash
cd medinova_ai
python -m venv venv
# Windows: venv\Scripts\activate
# macOS/Linux: source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Edit .env and add your GEMINI_API_KEY
python main.py
```

## Integrating Into an Existing Tkinter Codebase

1. Copy `services/gemini_service.py` and `services/pdf_service.py` into your project.
2. Instantiate `gemini = MedinovaGeminiService()` once at app startup (reads `GEMINI_API_KEY` securely via `python-dotenv` / `os.getenv`).
3. Wrap blocking API calls in `threading.Thread(..., daemon=True)` and dispatch UI updates back to Tkinter via `widget.after(0, ...)` so the interface stays responsive.
