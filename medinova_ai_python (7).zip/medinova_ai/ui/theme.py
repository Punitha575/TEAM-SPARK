"""Shared Tkinter clinical theme, typography, and non-blocking threading utilities."""

from __future__ import annotations

import threading
import tkinter as tk
from tkinter import ttk
from typing import Any, Callable

# Clinical Light Palette (clean, high-contrast, accessible)
PALETTE = {
    "bg": "#F4F7FA",
    "surface": "#FFFFFF",
    "surface_alt": "#EEF3F8",
    "sidebar": "#0F172A",
    "sidebar_hover": "#1E293B",
    "sidebar_active": "#0D9488",
    "primary": "#0D9488",
    "primary_dark": "#0F766E",
    "text": "#0F172A",
    "text_muted": "#475569",
    "border": "#CBD5E1",
    "danger_bg": "#FEF2F2",
    "danger_fg": "#B91C1C",
    "warn_bg": "#FFFBEB",
    "warn_fg": "#B45309",
    "ok_bg": "#ECFDF5",
    "ok_fg": "#047857",
}

FONTS = {
    "title": ("Segoe UI", 16, "bold"),
    "subtitle": ("Segoe UI", 10),
    "heading": ("Segoe UI", 12, "bold"),
    "body": ("Segoe UI", 10),
    "body_bold": ("Segoe UI", 10, "bold"),
    "mono": ("Consolas", 10),
}


def configure_ttk_styles(root: tk.Tk) -> None:
    style = ttk.Style(root)
    available = style.theme_names()
    if "clam" in available:
        style.theme_use("clam")

    style.configure("TFrame", background=PALETTE["bg"])
    style.configure("Card.TFrame", background=PALETTE["surface"], relief="flat")
    style.configure(
        "TLabel",
        background=PALETTE["bg"],
        foreground=PALETTE["text"],
        font=FONTS["body"],
    )
    style.configure(
        "Card.TLabel",
        background=PALETTE["surface"],
        foreground=PALETTE["text"],
        font=FONTS["body"],
    )
    style.configure(
        "Muted.TLabel",
        background=PALETTE["surface"],
        foreground=PALETTE["text_muted"],
        font=FONTS["subtitle"],
    )
    style.configure(
        "Primary.TButton",
        background=PALETTE["primary"],
        foreground="#FFFFFF",
        font=FONTS["body_bold"],
        padding=(14, 8),
        borderwidth=0,
    )
    style.map(
        "Primary.TButton",
        background=[("active", PALETTE["primary_dark"]), ("disabled", "#94A3B8")],
        foreground=[("disabled", "#F8FAFC")],
    )
    style.configure(
        "Secondary.TButton",
        background=PALETTE["surface_alt"],
        foreground=PALETTE["text"],
        font=FONTS["body"],
        padding=(12, 7),
        borderwidth=1,
    )
    style.configure(
        "Clinical.Horizontal.TProgressbar",
        troughcolor=PALETTE["surface_alt"],
        background=PALETTE["primary"],
        thickness=6,
    )


def run_in_background(
    widget: tk.Misc,
    worker: Callable[[], Any],
    on_success: Callable[[Any], None],
    on_error: Callable[[Exception], None],
) -> None:
    """Run blocking I/O (Gemini API / PyMuPDF) off the Tkinter mainloop safely."""

    def _task() -> None:
        try:
            result = worker()
        except Exception as exc:
            widget.after(0, lambda err=exc: on_error(err))
        else:
            widget.after(0, lambda res=result: on_success(res))

    threading.Thread(target=_task, daemon=True).start()


def make_output_text(parent: tk.Misc, height: int = 18) -> tuple[tk.Frame, tk.Text]:
    """Create a read-only scrollable Text widget for clinical AI output."""
    container = tk.Frame(parent, bg=PALETTE["surface"], bd=1, relief="solid", highlightthickness=0)
    container.configure(highlightbackground=PALETTE["border"], highlightcolor=PALETTE["border"])

    scrollbar = ttk.Scrollbar(container, orient="vertical")
    text_widget = tk.Text(
        container,
        height=height,
        wrap="word",
        font=FONTS["body"],
        bg=PALETTE["surface"],
        fg=PALETTE["text"],
        relief="flat",
        padx=12,
        pady=10,
        yscrollcommand=scrollbar.set,
        state="disabled",
    )
    scrollbar.config(command=text_widget.yview)
    scrollbar.pack(side="right", fill="y")
    text_widget.pack(side="left", fill="both", expand=True)
    return container, text_widget


def set_text_content(widget: tk.Text, content: str) -> None:
    widget.configure(state="normal")
    widget.delete("1.0", "end")
    widget.insert("1.0", content)
    widget.configure(state="disabled")
