"""Tkinter UI modules package for MEDINOVA AI."""
