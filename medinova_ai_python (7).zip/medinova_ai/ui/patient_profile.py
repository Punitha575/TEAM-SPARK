"""Module 1: Patient Profile Tkinter interface."""

from __future__ import annotations

import tkinter as tk
from tkinter import messagebox, ttk
from typing import Callable

from services.gemini_service import SUPPORTED_LANGUAGES
from services.profile_store import PatientProfile, ProfileStore
from ui.theme import FONTS, PALETTE


class PatientProfileFrame(ttk.Frame):
    """Manage persistent patient health context used across AI modules."""

    def __init__(
        self,
        parent: tk.Misc,
        store: ProfileStore,
        on_profile_saved: Callable[[PatientProfile], None],
    ) -> None:
        super().__init__(parent, style="TFrame")
        self.store = store
        self.on_profile_saved = on_profile_saved
        self.profile = self.store.load()

        self._vars: dict[str, tk.StringVar] = {
            "full_name": tk.StringVar(value=self.profile.full_name),
            "age": tk.StringVar(value=self.profile.age),
            "sex": tk.StringVar(value=self.profile.sex),
            "blood_group": tk.StringVar(value=self.profile.blood_group),
            "height_cm": tk.StringVar(value=self.profile.height_cm),
            "weight_kg": tk.StringVar(value=self.profile.weight_kg),
            "allergies": tk.StringVar(value=self.profile.allergies),
            "chronic_conditions": tk.StringVar(value=self.profile.chronic_conditions),
            "current_medications": tk.StringVar(value=self.profile.current_medications),
            "emergency_contact": tk.StringVar(value=self.profile.emergency_contact),
            "preferred_language": tk.StringVar(value=self.profile.preferred_language),
        }

        self._build_ui()
        self._update_bmi_label()

    def _build_ui(self) -> None:
        header = tk.Frame(self, bg=PALETTE["bg"])
        header.pack(fill="x", padx=20, pady=(16, 8))

        tk.Label(
            header,
            text="Patient Profile",
            font=FONTS["title"],
            bg=PALETTE["bg"],
            fg=PALETTE["text"],
        ).pack(anchor="w")
        tk.Label(
            header,
            text=(
                "Store baseline health details locally. When enabled, non-identifying clinical "
                "context (age, allergies, medications) grounds AI responses safely."
            ),
            font=FONTS["subtitle"],
            bg=PALETTE["bg"],
            fg=PALETTE["text_muted"],
            wraplength=760,
            justify="left",
        ).pack(anchor="w", pady=(2, 0))

        card = tk.Frame(
            self,
            bg=PALETTE["surface"],
            padx=20,
            pady=18,
            highlightbackground=PALETTE["border"],
            highlightthickness=1,
        )
        card.pack(fill="both", expand=True, padx=20, pady=(4, 16))
        card.columnconfigure(1, weight=1)
        card.columnconfigure(3, weight=1)

        fields = [
            ("Full Name", "full_name", 0, 0),
            ("Age (Years)", "age", 0, 2),
            ("Height (cm)", "height_cm", 2, 0),
            ("Weight (kg)", "weight_kg", 2, 2),
            ("Known Allergies", "allergies", 3, 0),
            ("Chronic Conditions", "chronic_conditions", 3, 2),
            ("Current Medications", "current_medications", 4, 0),
            ("Emergency Contact", "emergency_contact", 4, 2),
        ]

        for label_text, key, row, col in fields:
            tk.Label(
                card,
                text=label_text,
                font=FONTS["body_bold"],
                bg=PALETTE["surface"],
                fg=PALETTE["text"],
            ).grid(row=row, column=col, sticky="w", padx=(0, 8), pady=(8, 4))

            entry = ttk.Entry(card, textvariable=self._vars[key], font=FONTS["body"])
            entry.grid(row=row, column=col + 1, sticky="ew", padx=(0, 16), pady=(8, 4))

        # Row 1: Sex & Blood Group dropdowns
        tk.Label(
            card,
            text="Biological Sex",
            font=FONTS["body_bold"],
            bg=PALETTE["surface"],
            fg=PALETTE["text"],
        ).grid(row=1, column=0, sticky="w", padx=(0, 8), pady=(8, 4))
        ttk.Combobox(
            card,
            textvariable=self._vars["sex"],
            values=["Prefer not to say", "Female", "Male", "Other"],
            state="readonly",
        ).grid(row=1, column=1, sticky="ew", padx=(0, 16), pady=(8, 4))

        tk.Label(
            card,
            text="Blood Group",
            font=FONTS["body_bold"],
            bg=PALETTE["surface"],
            fg=PALETTE["text"],
        ).grid(row=1, column=2, sticky="w", padx=(0, 8), pady=(8, 4))
        ttk.Combobox(
            card,
            textvariable=self._vars["blood_group"],
            values=["Unknown", "A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"],
            state="readonly",
        ).grid(row=1, column=3, sticky="ew", padx=(0, 16), pady=(8, 4))

        # Row 5: Preferred Language & Live BMI
        tk.Label(
            card,
            text="Preferred Language",
            font=FONTS["body_bold"],
            bg=PALETTE["surface"],
            fg=PALETTE["text"],
        ).grid(row=5, column=0, sticky="w", padx=(0, 8), pady=(10, 4))
        ttk.Combobox(
            card,
            textvariable=self._vars["preferred_language"],
            values=SUPPORTED_LANGUAGES,
            state="readonly",
        ).grid(row=5, column=1, sticky="ew", padx=(0, 16), pady=(10, 4))

        self.bmi_label = tk.Label(
            card,
            text="Calculated BMI: --",
            font=FONTS["body_bold"],
            bg=PALETTE["surface_alt"],
            fg=PALETTE["primary_dark"],
            padx=12,
            pady=6,
        )
        self.bmi_label.grid(row=5, column=2, columnspan=2, sticky="w", pady=(10, 4))

        self._vars["height_cm"].trace_add("write", lambda *_: self._update_bmi_label())
        self._vars["weight_kg"].trace_add("write", lambda *_: self._update_bmi_label())

        # Action Bar
        actions = tk.Frame(card, bg=PALETTE["surface"])
        actions.grid(row=6, column=0, columnspan=4, sticky="ew", pady=(18, 4))

        ttk.Button(
            actions,
            text="Save Patient Profile",
            style="Primary.TButton",
            command=self._save_profile,
        ).pack(side="left")

        ttk.Button(
            actions,
            text="Reset Fields",
            style="Secondary.TButton",
            command=self._reset_profile,
        ).pack(side="left", padx=(10, 0))

        self.status_label = tk.Label(
            actions,
            text="",
            font=FONTS["subtitle"],
            bg=PALETTE["surface"],
            fg=PALETTE["ok_fg"],
        )
        self.status_label.pack(side="left", padx=(16, 0))

    def _build_profile_from_vars(self) -> PatientProfile:
        return PatientProfile(**{k: v.get().strip() for k, v in self._vars.items()})

    def _update_bmi_label(self) -> None:
        bmi = self._build_profile_from_vars().calculate_bmi()
        if bmi is None:
            self.bmi_label.configure(text="Calculated BMI: Enter valid height & weight")
        else:
            category = (
                "Underweight"
                if bmi < 18.5
                else "Normal range"
                if bmi < 25
                else "Overweight"
                if bmi < 30
                else "Obese range"
            )
            self.bmi_label.configure(text=f"Calculated BMI: {bmi} kg/m^2 ({category})")

    def _save_profile(self) -> None:
        age_val = self._vars["age"].get().strip()
        if age_val and (not age_val.isdigit() or int(age_val) < 0 or int(age_val) > 130):
            messagebox.showwarning("Invalid Age", "Please enter a valid age between 0 and 130.")
            return

        self.profile = self._build_profile_from_vars()
        self.store.save(self.profile)
        self.status_label.configure(text="Profile saved locally.")
        self.on_profile_saved(self.profile)

    def _reset_profile(self) -> None:
        defaults = PatientProfile()
        for key, var in self._vars.items():
            var.set(getattr(defaults, key))
        self.status_label.configure(text="Fields cleared (click Save to persist).")
