"""Module 3: Medicine Guide Tkinter interface."""

from __future__ import annotations

import tkinter as tk
from tkinter import messagebox, ttk
from typing import Callable

from services.gemini_service import MedinovaGeminiService
from ui.theme import FONTS, PALETTE, make_output_text, run_in_background, set_text_content


class MedicineGuideFrame(ttk.Frame):
    """Look up medicine uses, precautions, side effects, and profile interactions."""

    QUICK_MEDICINES = [
        "Paracetamol (Acetaminophen)",
        "Ibuprofen",
        "Metformin",
        "Amoxicillin",
        "Atorvastatin",
        "Omeprazole",
    ]

    def __init__(
        self,
        parent: tk.Misc,
        gemini: MedinovaGeminiService,
        get_language: Callable[[], str],
        get_patient_context: Callable[[], str],
    ) -> None:
        super().__init__(parent, style="TFrame")
        self.gemini = gemini
        self.get_language = get_language
        self.get_patient_context = get_patient_context

        self.med_var = tk.StringVar()
        self.question_var = tk.StringVar()
        self._build_ui()

    def _build_ui(self) -> None:
        header = tk.Frame(self, bg=PALETTE["bg"])
        header.pack(fill="x", padx=20, pady=(16, 8))

        tk.Label(
            header,
            text="Medicine Guide (Clinical Reference)",
            font=FONTS["title"],
            bg=PALETTE["bg"],
            fg=PALETTE["text"],
        ).pack(anchor="w")
        tk.Label(
            header,
            text=(
                "Evidence-based medicine uses, precautions, side effects, and allergy/interaction "
                "checks grounded in WHO, FDA/DailyMed, BNF, and MedlinePlus references."
            ),
            font=FONTS["subtitle"],
            bg=PALETTE["bg"],
            fg=PALETTE["text_muted"],
        ).pack(anchor="w", pady=(2, 0))

        card = tk.Frame(
            self,
            bg=PALETTE["surface"],
            padx=16,
            pady=14,
            highlightbackground=PALETTE["border"],
            highlightthickness=1,
        )
        card.pack(fill="x", padx=20, pady=(4, 10))
        card.columnconfigure(1, weight=1)

        tk.Label(
            card, text="Medicine Name:", font=FONTS["body_bold"], bg=PALETTE["surface"]
        ).grid(row=0, column=0, sticky="w", padx=(0, 10), pady=4)
        med_entry = ttk.Entry(card, textvariable=self.med_var, font=FONTS["body"])
        med_entry.grid(row=0, column=1, sticky="ew", pady=4)
        med_entry.bind("<Return>", lambda _e: self._on_lookup())

        tk.Label(
            card, text="Specific Question (optional):", font=FONTS["body_bold"], bg=PALETTE["surface"]
        ).grid(row=1, column=0, sticky="w", padx=(0, 10), pady=4)
        ttk.Entry(card, textvariable=self.question_var, font=FONTS["body"]).grid(
            row=1, column=1, sticky="ew", pady=4
        )

        quick_row = tk.Frame(card, bg=PALETTE["surface"])
        quick_row.grid(row=2, column=0, columnspan=2, sticky="w", pady=(8, 6))
        tk.Label(
            quick_row, text="Quick Lookup:", font=FONTS["subtitle"], bg=PALETTE["surface"], fg=PALETTE["text_muted"]
        ).pack(side="left", padx=(0, 8))
        for med in self.QUICK_MEDICINES:
            ttk.Button(
                quick_row,
                text=med.split(" ")[0],
                style="Secondary.TButton",
                command=lambda m=med: self._select_quick_medicine(m),
            ).pack(side="left", padx=(0, 6))

        controls = tk.Frame(card, bg=PALETTE["surface"])
        controls.grid(row=3, column=0, columnspan=2, sticky="ew", pady=(8, 0))

        self.lookup_btn = ttk.Button(
            controls,
            text="Get Medicine Guide",
            style="Primary.TButton",
            command=self._on_lookup,
        )
        self.lookup_btn.pack(side="left")

        self.progress = ttk.Progressbar(
            controls,
            mode="indeterminate",
            length=150,
            style="Clinical.Horizontal.TProgressbar",
        )
        self.status_lbl = tk.Label(
            controls,
            text="Ready",
            font=FONTS["subtitle"],
            bg=PALETTE["surface"],
            fg=PALETTE["text_muted"],
        )
        self.status_lbl.pack(side="left", padx=(12, 0))

        out_container, self.output_text = make_output_text(self, height=16)
        out_container.pack(fill="both", expand=True, padx=20, pady=(0, 16))
        set_text_content(
            self.output_text,
            "Enter a generic or brand medicine name above (e.g., Metformin, Paracetamol, "
            "Amoxicillin) to view uses, precautions, side effects, and profile interaction notes.",
        )

    def _select_quick_medicine(self, medicine: str) -> None:
        self.med_var.set(medicine)
        self._on_lookup()

    def _set_loading(self, loading: bool, message: str = "") -> None:
        if loading:
            self.lookup_btn.configure(state="disabled")
            self.progress.pack(side="left", padx=(12, 8))
            self.progress.start(12)
            self.status_lbl.configure(text=message, fg=PALETTE["primary_dark"])
        else:
            self.lookup_btn.configure(state="normal")
            self.progress.stop()
            self.progress.pack_forget()
            self.status_lbl.configure(text=message, fg=PALETTE["text_muted"])

    def _on_lookup(self) -> None:
        medicine = self.med_var.get().strip()
        if not medicine:
            messagebox.showwarning("Missing Medicine", "Please enter a medicine name to look up.")
            return

        language = self.get_language()
        patient_ctx = self.get_patient_context()
        extra_q = self.question_var.get().strip()

        self._set_loading(True, f"Fetching reference guide ({language})...")
        set_text_content(self.output_text, f"Loading reference information for {medicine}...")

        def _worker() -> str:
            return self.gemini.lookup_medicine(
                medicine_name=medicine,
                language=language,
                patient_context=patient_ctx,
                extra_question=extra_q,
            )

        def _done(result: str) -> None:
            self._set_loading(False, f"Completed ({language})")
            set_text_content(self.output_text, result)

        def _err(exc: Exception) -> None:
            self._set_loading(False, "Request failed")
            set_text_content(self.output_text, f"Error: {exc}")
            messagebox.showerror("Medicine Guide Error", str(exc))

        run_in_background(self, _worker, _done, _err)
