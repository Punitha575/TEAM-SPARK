"""Module 2: AI Symptom Checker Tkinter interface (General Health Info, NOT a Diagnosis)."""

from __future__ import annotations

import tkinter as tk
from tkinter import messagebox, ttk
from typing import Callable

from services.gemini_service import MedinovaGeminiService
from ui.theme import FONTS, PALETTE, make_output_text, run_in_background, set_text_content


class SymptomCheckerFrame(ttk.Frame):
    """Collect symptoms and fetch non-diagnostic educational insights from Gemini AI."""

    RED_FLAG_OPTIONS = [
        "Chest pain or tightness",
        "Shortness of breath",
        "Sudden weakness / numbness / slurred speech",
        "High fever (>103°F / 39.4°C)",
        "Severe bleeding or fainting",
    ]

    def __init__(
        self,
        parent: tk.Misc,
        gemini: MedinovaGeminiService,
        get_language: Callable[[], str],
        get_patient_context: Callable[[], str],
    ) -> None:
        super().__init__(parent, style="TFrame")
        self.gemini = gemini
        self.get_language = get_language
        self.get_patient_context = get_patient_context

        self.duration_var = tk.StringVar(value="1–3 days")
        self.severity_var = tk.StringVar(value="Moderate")
        self.red_flag_vars: dict[str, tk.BooleanVar] = {
            item: tk.BooleanVar(value=False) for item in self.RED_FLAG_OPTIONS
        }
        self._build_ui()

    def _build_ui(self) -> None:
        header = tk.Frame(self, bg=PALETTE["bg"])
        header.pack(fill="x", padx=20, pady=(16, 8))

        tk.Label(
            header,
            text="Symptom Checker (General Health Information)",
            font=FONTS["title"],
            bg=PALETTE["bg"],
            fg=PALETTE["text"],
        ).pack(anchor="w")
        tk.Label(
            header,
            text=(
                "Provides general educational information and possible causes to discuss with a "
                "doctor. This tool does NOT provide a medical diagnosis."
            ),
            font=FONTS["subtitle"],
            bg=PALETTE["bg"],
            fg=PALETTE["warn_fg"],
        ).pack(anchor="w", pady=(2, 0))

        # Input Card
        card = tk.Frame(
            self,
            bg=PALETTE["surface"],
            padx=16,
            pady=14,
            highlightbackground=PALETTE["border"],
            highlightthickness=1,
        )
        card.pack(fill="x", padx=20, pady=(4, 10))

        tk.Label(
            card,
            text="Describe your symptoms (what you feel, where, and what makes it better or worse):",
            font=FONTS["body_bold"],
            bg=PALETTE["surface"],
            fg=PALETTE["text"],
        ).pack(anchor="w")

        self.symptoms_input = tk.Text(
            card,
            height=4,
            wrap="word",
            font=FONTS["body"],
            bg=PALETTE["bg"],
            fg=PALETTE["text"],
            relief="solid",
            bd=1,
            padx=10,
            pady=8,
        )
        self.symptoms_input.pack(fill="x", pady=(6, 10))

        meta_row = tk.Frame(card, bg=PALETTE["surface"])
        meta_row.pack(fill="x", pady=(0, 8))

        tk.Label(meta_row, text="Duration:", font=FONTS["body_bold"], bg=PALETTE["surface"]).pack(
            side="left"
        )
        ttk.Combobox(
            meta_row,
            textvariable=self.duration_var,
            values=["Today / Few hours", "1–3 days", "4–7 days", "1–2 weeks", "Over 2 weeks"],
            width=18,
        ).pack(side="left", padx=(6, 20))

        tk.Label(meta_row, text="Severity:", font=FONTS["body_bold"], bg=PALETTE["surface"]).pack(
            side="left"
        )
        ttk.Combobox(
            meta_row,
            textvariable=self.severity_var,
            values=["Mild", "Moderate", "Severe"],
            state="readonly",
            width=14,
        ).pack(side="left", padx=(6, 0))

        tk.Label(
            card,
            text="Emergency Warning Signs (check any that apply):",
            font=FONTS["body_bold"],
            bg=PALETTE["surface"],
            fg=PALETTE["danger_fg"],
        ).pack(anchor="w", pady=(6, 4))

        flags_frame = tk.Frame(card, bg=PALETTE["surface"])
        flags_frame.pack(fill="x")
        for idx, label in enumerate(self.RED_FLAG_OPTIONS):
            cb = tk.Checkbutton(
                flags_frame,
                text=label,
                variable=self.red_flag_vars[label],
                bg=PALETTE["surface"],
                fg=PALETTE["text"],
                activebackground=PALETTE["surface"],
                font=FONTS["subtitle"],
            )
            cb.grid(row=idx // 2, column=idx % 2, sticky="w", padx=(0, 18), pady=1)

        controls = tk.Frame(card, bg=PALETTE["surface"])
        controls.pack(fill="x", pady=(10, 0))

        self.analyze_btn = ttk.Button(
            controls,
            text="Analyze Symptoms",
            style="Primary.TButton",
            command=self._on_analyze,
        )
        self.analyze_btn.pack(side="left")

        ttk.Button(
            controls,
            text="Clear",
            style="Secondary.TButton",
            command=self._clear,
        ).pack(side="left", padx=(8, 12))

        self.progress = ttk.Progressbar(
            controls,
            mode="indeterminate",
            length=150,
            style="Clinical.Horizontal.TProgressbar",
        )
        self.status_lbl = tk.Label(
            controls,
            text="Ready",
            font=FONTS["subtitle"],
            bg=PALETTE["surface"],
            fg=PALETTE["text_muted"],
        )
        self.status_lbl.pack(side="left")

        # Output area
        out_container, self.output_text = make_output_text(self, height=14)
        out_container.pack(fill="both", expand=True, padx=20, pady=(0, 16))
        set_text_content(
            self.output_text,
            "Enter your symptoms above and click 'Analyze Symptoms' to receive general "
            "health information and possible non-diagnostic causes in your selected language.",
        )

    def _clear(self) -> None:
        self.symptoms_input.delete("1.0", "end")
        for var in self.red_flag_vars.values():
            var.set(False)
        set_text_content(self.output_text, "")
        self.status_lbl.configure(text="Ready", fg=PALETTE["text_muted"])

    def _set_loading(self, loading: bool, message: str = "") -> None:
        if loading:
            self.analyze_btn.configure(state="disabled")
            self.progress.pack(side="left", padx=(0, 10))
            self.progress.start(12)
            self.status_lbl.configure(text=message, fg=PALETTE["primary_dark"])
        else:
            self.analyze_btn.configure(state="normal")
            self.progress.stop()
            self.progress.pack_forget()
            self.status_lbl.configure(text=message, fg=PALETTE["text_muted"])

    def _on_analyze(self) -> None:
        symptoms = self.symptoms_input.get("1.0", "end").strip()
        if not symptoms:
            messagebox.showwarning("Missing Symptoms", "Please describe your symptoms first.")
            return

        red_flags = [k for k, var in self.red_flag_vars.items() if var.get()]
        language = self.get_language()
        patient_ctx = self.get_patient_context()
        duration = self.duration_var.get()
        severity = self.severity_var.get()

        self._set_loading(True, f"Analyzing symptoms with Gemini AI ({language})...")
        set_text_content(self.output_text, "Generating general health guidance, please wait...")

        def _worker() -> str:
            return self.gemini.check_symptoms(
                symptoms=symptoms,
                duration=duration,
                severity=severity,
                red_flags=red_flags,
                language=language,
                patient_context=patient_ctx,
            )

        def _done(result: str) -> None:
            self._set_loading(False, f"Completed ({language})")
            set_text_content(self.output_text, result)

        def _err(exc: Exception) -> None:
            self._set_loading(False, "Request failed")
            set_text_content(self.output_text, f"Error: {exc}")
            messagebox.showerror("Symptom Checker Error", str(exc))

        run_in_background(self, _worker, _done, _err)
