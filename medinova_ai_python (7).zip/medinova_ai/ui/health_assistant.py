"""Module 4: AI Health Assistant (Multi-turn Gemini Chat) Tkinter interface."""

from __future__ import annotations

import tkinter as tk
from tkinter import messagebox, ttk
from typing import Callable, Optional

from services.gemini_service import MedinovaGeminiService
from ui.theme import FONTS, PALETTE, run_in_background


class HealthAssistantFrame(ttk.Frame):
    """Open-ended multilingual conversational health assistant powered by Gemini AI."""

    QUICK_PROMPTS = [
        "How can I read an HbA1c blood sugar report?",
        "Suggest a balanced vegetarian diet for iron deficiency.",
        "What preventive vaccines should adults review with their doctor?",
    ]

    def __init__(
        self,
        parent: tk.Misc,
        gemini: MedinovaGeminiService,
        get_language: Callable[[], str],
        get_patient_context: Callable[[], str],
    ) -> None:
        super().__init__(parent, style="TFrame")
        self.gemini = gemini
        self.get_language = get_language
        self.get_patient_context = get_patient_context

        self._chat_session = None
        self._session_signature: Optional[tuple[str, str]] = None
        self._build_ui()

    def _build_ui(self) -> None:
        header = tk.Frame(self, bg=PALETTE["bg"])
        header.pack(fill="x", padx=20, pady=(16, 8))

        top_row = tk.Frame(header, bg=PALETTE["bg"])
        top_row.pack(fill="x")

        tk.Label(
            top_row,
            text="AI Health Assistant",
            font=FONTS["title"],
            bg=PALETTE["bg"],
            fg=PALETTE["text"],
        ).pack(side="left")

        ttk.Button(
            top_row,
            text="New Conversation",
            style="Secondary.TButton",
            command=self._reset_chat,
        ).pack(side="right")

        tk.Label(
            header,
            text="Ask open-ended health, wellness, nutrition, or preventive care questions in any supported language.",
            font=FONTS["subtitle"],
            bg=PALETTE["bg"],
            fg=PALETTE["text_muted"],
        ).pack(anchor="w", pady=(2, 0))

        # Quick starter bar
        quick_frame = tk.Frame(self, bg=PALETTE["bg"])
        quick_frame.pack(fill="x", padx=20, pady=(0, 8))
        for prompt in self.QUICK_PROMPTS:
            ttk.Button(
                quick_frame,
                text=prompt[:42] + ("..." if len(prompt) > 42 else ""),
                style="Secondary.TButton",
                command=lambda p=prompt: self._send_quick(p),
            ).pack(side="left", padx=(0, 8))

        # Transcript container
        chat_box = tk.Frame(
            self,
            bg=PALETTE["surface"],
            highlightbackground=PALETTE["border"],
            highlightthickness=1,
        )
        chat_box.pack(fill="both", expand=True, padx=20, pady=(0, 10))

        scrollbar = ttk.Scrollbar(chat_box, orient="vertical")
        self.transcript = tk.Text(
            chat_box,
            wrap="word",
            font=FONTS["body"],
            bg=PALETTE["surface"],
            fg=PALETTE["text"],
            relief="flat",
            padx=14,
            pady=12,
            yscrollcommand=scrollbar.set,
            state="disabled",
        )
        scrollbar.config(command=self.transcript.yview)
        scrollbar.pack(side="right", fill="y")
        self.transcript.pack(side="left", fill="both", expand=True)

        self.transcript.tag_configure("user_label", font=FONTS["body_bold"], foreground=PALETTE["primary_dark"])
        self.transcript.tag_configure("ai_label", font=FONTS["body_bold"], foreground="#1D4ED8")
        self.transcript.tag_configure("err_label", font=FONTS["body_bold"], foreground=PALETTE["danger_fg"])
        self.transcript.tag_configure("sys_note", font=FONTS["subtitle"], foreground=PALETTE["text_muted"])

        # Input bar
        composer = tk.Frame(self, bg=PALETTE["bg"])
        composer.pack(fill="x", padx=20, pady=(0, 16))

        self.progress = ttk.Progressbar(
            composer,
            mode="indeterminate",
            length=120,
            style="Clinical.Horizontal.TProgressbar",
        )
        self.status_lbl = tk.Label(
            composer,
            text="",
            font=FONTS["subtitle"],
            bg=PALETTE["bg"],
            fg=PALETTE["text_muted"],
        )

        input_row = tk.Frame(composer, bg=PALETTE["bg"])
        input_row.pack(fill="x")

        self.input_var = tk.StringVar()
        self.input_entry = ttk.Entry(input_row, textvariable=self.input_var, font=FONTS["body"])
        self.input_entry.pack(side="left", fill="x", expand=True, padx=(0, 10), ipady=5)
        self.input_entry.bind("<Return>", lambda _e: self._on_send())

        self.send_btn = ttk.Button(
            input_row,
            text="Send Question",
            style="Primary.TButton",
            command=self._on_send,
        )
        self.send_btn.pack(side="right")

        self._append_message(
            "sys_note",
            "MEDINOVA AI Assistant ready. Your questions are answered via Google Gemini AI "
            "in the language selected in the top bar.",
        )

    def _append_message(self, tag: str, text: str, prefix: str = "") -> None:
        self.transcript.configure(state="normal")
        if prefix:
            self.transcript.insert("end", prefix + "\n", tag)
        self.transcript.insert("end", text.strip() + "\n\n")
        self.transcript.see("end")
        self.transcript.configure(state="disabled")

    def _reset_chat(self) -> None:
        self._chat_session = None
        self._session_signature = None
        self.transcript.configure(state="normal")
        self.transcript.delete("1.0", "end")
        self.transcript.configure(state="disabled")
        self._append_message("sys_note", "Started a new conversation session.")

    def _send_quick(self, prompt: str) -> None:
        self.input_var.set(prompt)
        self._on_send()

    def _set_loading(self, loading: bool, message: str = "") -> None:
        if loading:
            self.send_btn.configure(state="disabled")
            self.input_entry.configure(state="disabled")
            self.progress.pack(side="left", pady=(0, 6))
            self.progress.start(12)
            self.status_lbl.configure(text=message, fg=PALETTE["primary_dark"])
            self.status_lbl.pack(side="left", padx=(10, 0), pady=(0, 6))
        else:
            self.send_btn.configure(state="normal")
            self.input_entry.configure(state="normal")
            self.progress.stop()
            self.progress.pack_forget()
            self.status_lbl.pack_forget()

    def _on_send(self) -> None:
        message = self.input_var.get().strip()
        if not message:
            return

        language = self.get_language()
        patient_ctx = self.get_patient_context()
        self.input_var.set("")
        self._append_message("user_label", message, prefix="You:")
        self._set_loading(True, f"MEDINOVA AI is thinking ({language})...")

        def _worker() -> str:
            sig = (language, patient_ctx)
            if self._chat_session is None or self._session_signature != sig:
                self._chat_session = self.gemini.create_assistant_chat(
                    language=language,
                    patient_context=patient_ctx,
                )
                self._session_signature = sig
            return self.gemini.send_chat_message(self._chat_session, message)

        def _done(reply: str) -> None:
            self._set_loading(False)
            self._append_message("ai_label", reply, prefix=f"MEDINOVA AI ({language}):")
            self.input_entry.focus_set()

        def _err(exc: Exception) -> None:
            self._set_loading(False)
            self._append_message("err_label", str(exc), prefix="Error:")
            messagebox.showerror("AI Health Assistant Error", str(exc))

        run_in_background(self, _worker, _done, _err)
