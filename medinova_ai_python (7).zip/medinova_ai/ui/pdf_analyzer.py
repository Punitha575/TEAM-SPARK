"""Module 5: Medical PDF Analyzer Tkinter interface using PyMuPDF + Gemini AI."""

from __future__ import annotations

import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from typing import Callable, Optional

from services.gemini_service import MedinovaGeminiService
from services.pdf_service import ExtractedPDF, extract_medical_pdf
from ui.theme import FONTS, PALETTE, make_output_text, run_in_background, set_text_content


class PDFAnalyzerFrame(ttk.Frame):
    """Extract readable text from medical PDFs with PyMuPDF and analyze with Gemini AI."""

    def __init__(
        self,
        parent: tk.Misc,
        gemini: MedinovaGeminiService,
        get_language: Callable[[], str],
        get_patient_context: Callable[[], str],
    ) -> None:
        super().__init__(parent, style="TFrame")
        self.gemini = gemini
        self.get_language = get_language
        self.get_patient_context = get_patient_context

        self._extracted: Optional[ExtractedPDF] = None
        self.question_var = tk.StringVar()
        self._build_ui()

    def _build_ui(self) -> None:
        header = tk.Frame(self, bg=PALETTE["bg"])
        header.pack(fill="x", padx=20, pady=(16, 8))

        tk.Label(
            header,
            text="Medical PDF Analyzer (PyMuPDF + Gemini AI)",
            font=FONTS["title"],
            bg=PALETTE["bg"],
            fg=PALETTE["text"],
        ).pack(anchor="w")
        tk.Label(
            header,
            text=(
                "Upload lab reports, discharge summaries, or prescriptions (.pdf). PyMuPDF extracts "
                "readable text locally, and Gemini AI explains key findings in your selected language."
            ),
            font=FONTS["subtitle"],
            bg=PALETTE["bg"],
            fg=PALETTE["text_muted"],
        ).pack(anchor="w", pady=(2, 0))

        # Upload & Action Card
        card = tk.Frame(
            self,
            bg=PALETTE["surface"],
            padx=16,
            pady=14,
            highlightbackground=PALETTE["border"],
            highlightthickness=1,
        )
        card.pack(fill="x", padx=20, pady=(4, 10))
        card.columnconfigure(1, weight=1)

        top_controls = tk.Frame(card, bg=PALETTE["surface"])
        top_controls.grid(row=0, column=0, columnspan=2, sticky="ew")

        self.upload_btn = ttk.Button(
            top_controls,
            text="Upload Medical PDF...",
            style="Primary.TButton",
            command=self._on_upload_pdf,
        )
        self.upload_btn.pack(side="left")

        self.analyze_btn = ttk.Button(
            top_controls,
            text="Analyze with Gemini AI",
            style="Secondary.TButton",
            command=self._on_analyze_pdf,
            state="disabled",
        )
        self.analyze_btn.pack(side="left", padx=(10, 14))

        self.file_lbl = tk.Label(
            top_controls,
            text="No PDF selected",
            font=FONTS["body_bold"],
            bg=PALETTE["surface"],
            fg=PALETTE["text_muted"],
        )
        self.file_lbl.pack(side="left")

        tk.Label(
            card,
            text="Focus Question (optional):",
            font=FONTS["body_bold"],
            bg=PALETTE["surface"],
        ).grid(row=1, column=0, sticky="w", padx=(0, 10), pady=(10, 4))
        ttk.Entry(card, textvariable=self.question_var, font=FONTS["body"]).grid(
            row=1, column=1, sticky="ew", pady=(10, 4)
        )

        status_row = tk.Frame(card, bg=PALETTE["surface"])
        status_row.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(6, 0))

        self.progress = ttk.Progressbar(
            status_row,
            mode="indeterminate",
            length=150,
            style="Clinical.Horizontal.TProgressbar",
        )
        self.status_lbl = tk.Label(
            status_row,
            text="Ready",
            font=FONTS["subtitle"],
            bg=PALETTE["surface"],
            fg=PALETTE["text_muted"],
        )
        self.status_lbl.pack(side="left")

        # Notebook tabs for AI Explanation vs Extracted Raw Text
        tabs = ttk.Notebook(self)
        tabs.pack(fill="both", expand=True, padx=20, pady=(0, 16))

        ai_tab = ttk.Frame(tabs)
        raw_tab = ttk.Frame(tabs)
        tabs.add(ai_tab, text="AI Clinical Explanation")
        tabs.add(raw_tab, text="Extracted PDF Text (PyMuPDF)")

        ai_container, self.ai_output = make_output_text(ai_tab, height=15)
        ai_container.pack(fill="both", expand=True, padx=4, pady=4)
        set_text_content(
            self.ai_output,
            "Upload a medical PDF to extract text with PyMuPDF and view a clear AI explanation here.",
        )

        raw_container, self.raw_output = make_output_text(raw_tab, height=15)
        raw_container.pack(fill="both", expand=True, padx=4, pady=4)
        set_text_content(self.raw_output, "Extracted PDF text will appear here.")

    def _set_loading(self, loading: bool, message: str = "") -> None:
        if loading:
            self.upload_btn.configure(state="disabled")
            self.analyze_btn.configure(state="disabled")
            self.progress.pack(side="left", padx=(0, 10))
            self.progress.start(12)
            self.status_lbl.configure(text=message, fg=PALETTE["primary_dark"])
        else:
            self.upload_btn.configure(state="normal")
            self.analyze_btn.configure(state="normal" if self._extracted else "disabled")
            self.progress.stop()
            self.progress.pack_forget()
            self.status_lbl.configure(text=message, fg=PALETTE["text_muted"])

    def _on_upload_pdf(self) -> None:
        path = filedialog.askopenfilename(
            title="Select Medical PDF Report",
            filetypes=[("PDF Documents", "*.pdf"), ("All Files", "*.*")],
        )
        if not path:
            return

        self._set_loading(True, "Extracting text using PyMuPDF...")
        set_text_content(self.raw_output, "Extracting readable text from PDF...")

        def _worker() -> ExtractedPDF:
            return extract_medical_pdf(path)

        def _done(extracted: ExtractedPDF) -> None:
            self._extracted = extracted
            self._set_loading(
                False,
                f"Extracted {extracted.page_count} page(s), {extracted.total_characters:,} chars",
            )
            self.file_lbl.configure(
                text=f"{extracted.file_name} ({extracted.page_count} pages)",
                fg=PALETTE["text"],
            )
            set_text_content(self.raw_output, extracted.full_text)
            # Automatically run Gemini analysis after extraction
            self._on_analyze_pdf()

        def _err(exc: Exception) -> None:
            self._extracted = None
            self._set_loading(False, "PDF extraction failed")
            set_text_content(self.raw_output, f"PDF Error: {exc}")
            messagebox.showerror("PDF Extraction Error", str(exc))

        run_in_background(self, _worker, _done, _err)

    def _on_analyze_pdf(self) -> None:
        if not self._extracted:
            messagebox.showwarning("No PDF Loaded", "Please upload a medical PDF file first.")
            return

        language = self.get_language()
        patient_ctx = self.get_patient_context()
        question = self.question_var.get().strip()
        extracted = self._extracted

        self._set_loading(True, f"Analyzing report with Gemini AI ({language})...")
        set_text_content(self.ai_output, "Generating structured medical report explanation...")

        def _worker() -> str:
            return self.gemini.analyze_medical_pdf_text(
                extracted_text=extracted.full_text,
                file_name=extracted.file_name,
                language=language,
                patient_context=patient_ctx,
                custom_question=question,
            )

        def _done(result: str) -> None:
            note = (
                "\n\n[Note: Document exceeded 28,000 characters; first 28,000 characters were analyzed.]"
                if extracted.truncated_for_ai
                else ""
            )
            self._set_loading(False, f"Analysis complete ({language})")
            set_text_content(self.ai_output, result + note)

        def _err(exc: Exception) -> None:
            self._set_loading(False, "Analysis failed")
            set_text_content(self.ai_output, f"Error: {exc}")
            messagebox.showerror("PDF Analysis Error", str(exc))

        run_in_background(self, _worker, _done, _err)
