"""Google Gemini AI service layer for MEDINOVA AI (google-genai SDK)."""

from __future__ import annotations

import os
import time
from typing import Callable, Optional

from dotenv import load_dotenv
from google import genai
from google.genai import errors as genai_errors
from google.genai import types

# Load environment variables from .env (if present) without overwriting OS env vars
load_dotenv(override=False)

SUPPORTED_LANGUAGES = [
    "English",
    "Tamil (தமிழ்)",
    "Hindi (हिन्दी)",
    "Telugu (తెలుగు)",
    "Malayalam (മലയാളം)",
    "Kannada (ಕನ್ನಡ)",
    "Bengali (বাংলা)",
    "Marathi (मराठी)",
    "Spanish (Español)",
    "French (Français)",
    "German (Deutsch)",
    "Arabic (العربية)",
    "Chinese Simplified (简体中文)",
    "Japanese (日本語)",
]

DEFAULT_MODEL = os.getenv("GEMINI_MODEL", "gemini-4-hydrogen").strip() or "gemini-4-hydrogen"


class GeminiServiceError(Exception):
    """Base exception for Gemini service failures with user-friendly messages."""


class MissingAPIKeyError(GeminiServiceError):
    """Raised when GEMINI_API_KEY is missing or still set to a placeholder."""


def _language_directive(language: str) -> str:
    return (
        f"Respond clearly, accurately, and empathetically in {language}. "
        "If responding in a non-English language, keep standard medical/drug terms "
        "understandable by including the common English clinical term in parentheses "
        "where helpful (e.g., for medicine names or lab markers)."
    )


class MedinovaGeminiService:
    """Centralized, thread-safe Google Gemini client wrapper for all MEDINOVA AI modules."""

    def __init__(self, model_name: Optional[str] = None) -> None:
        self.model_name = model_name or DEFAULT_MODEL
        self._client: Optional[genai.Client] = None

    def _get_client(self) -> genai.Client:
        api_key = (os.getenv("GEMINI_API_KEY") or "").strip()
        if not api_key or api_key in {"your_gemini_api_key_here", "MY_GEMINI_API_KEY"}:
            raise MissingAPIKeyError(
                "GEMINI_API_KEY is not configured. Add GEMINI_API_KEY=your_key to your .env "
                "file or set it in your operating system environment variables, then restart."
            )
        if self._client is None:
            self._client = genai.Client(api_key=api_key)
        return self._client

    def is_configured(self) -> bool:
        api_key = (os.getenv("GEMINI_API_KEY") or "").strip()
        return bool(api_key) and api_key not in {"your_gemini_api_key_here", "MY_GEMINI_API_KEY"}

    def _call_with_retry(self, fn: Callable[[], str], max_attempts: int = 3) -> str:
        """Execute a Gemini request with exponential backoff on transient errors."""
        last_error: Optional[Exception] = None
        for attempt in range(1, max_attempts + 1):
            try:
                text = fn()
                if not text or not text.strip():
                    raise GeminiServiceError(
                        "Gemini returned an empty response. Please refine your query and try again."
                    )
                return text.strip()
            except GeminiServiceError:
                raise
            except genai_errors.APIError as exc:
                last_error = exc
                status_code = getattr(exc, "code", None)
                message = getattr(exc, "message", str(exc))

                if status_code in (400, 401, 403):
                    raise GeminiServiceError(
                        f"Gemini API authentication/permission error ({status_code}): {message}. "
                        "Please verify your GEMINI_API_KEY environment variable."
                    ) from exc
                if status_code == 404:
                    raise GeminiServiceError(
                        f"Model '{self.model_name}' was not found ({status_code}). "
                        "Check GEMINI_MODEL in your .env file."
                    ) from exc
                if status_code in (429, 500, 502, 503, 504) and attempt < max_attempts:
                    time.sleep(1.5 * (2 ** (attempt - 1)))
                    continue
                if status_code == 429:
                    raise GeminiServiceError(
                        "Gemini API rate limit or quota reached (429). Please wait a moment and retry."
                    ) from exc
                raise GeminiServiceError(f"Gemini API error ({status_code}): {message}") from exc
            except Exception as exc:
                last_error = exc
                if attempt < max_attempts:
                    time.sleep(1.2 * attempt)
                    continue
                raise GeminiServiceError(
                    f"Network or unexpected error while contacting Gemini AI: {exc}"
                ) from exc

        raise GeminiServiceError(f"Request failed after retries: {last_error}")

    # ------------------------------------------------------------------
    # Module 2: Symptom Checker (General Health Info, NOT a Diagnosis)
    # ------------------------------------------------------------------
    def check_symptoms(
        self,
        symptoms: str,
        duration: str,
        severity: str,
        red_flags: list[str],
        language: str = "English",
        patient_context: str = "",
    ) -> str:
        client = self._get_client()
        system_instruction = (
            "You are MEDINOVA AI's Symptom Information Module. "
            "CRITICAL SAFETY RULES:\n"
            "1. You MUST provide general health education and possible non-diagnostic causes ONLY. "
            "Explicitly state that this is NOT a medical diagnosis.\n"
            "2. Never prescribe medications or give definitive diagnostic conclusions.\n"
            "3. If red-flag or severe symptoms are present (e.g., chest pain, shortness of breath, "
            "neurological deficits, severe bleeding, high persistent fever), immediately lead with an "
            "urgent warning advising emergency medical evaluation.\n"
            "4. Structure your output clearly with these headings:\n"
            "   - Important Notice (Non-Diagnostic Guidance)\n"
            "   - Urgency & Red-Flag Assessment\n"
            "   - Possible General Causes to Discuss with a Clinician\n"
            "   - Safe General Self-Care & Comfort Measures\n"
            "   - Helpful Questions for Your Healthcare Provider\n"
            + _language_directive(language)
        )

        prompt_sections = [
            f"Reported Symptoms: {symptoms.strip()}",
            f"Duration: {duration.strip() or 'Not specified'}",
            f"Self-Reported Severity: {severity}",
        ]
        if red_flags:
            prompt_sections.append(f"Selected Warning Signs: {', '.join(red_flags)}")
        if patient_context.strip():
            prompt_sections.append(f"Patient Context: {patient_context.strip()}")

        prompt = "\n".join(prompt_sections)

        def _run() -> str:
            resp = client.models.generate_content(
                model=self.model_name,
                contents=prompt,
                config=types.GenerateContentConfig(system_instruction=system_instruction),
            )
            return resp.text or ""

        return self._call_with_retry(_run)

    # ------------------------------------------------------------------
    # Module 3: Medicine Guide (Evidence-Based Reference Information)
    # ------------------------------------------------------------------
    def lookup_medicine(
        self,
        medicine_name: str,
        language: str = "English",
        patient_context: str = "",
        extra_question: str = "",
    ) -> str:
        client = self._get_client()
        system_instruction = (
            "You are MEDINOVA AI's Evidence-Based Medicine Reference Module. "
            "Provide accurate, objective pharmacological reference information aligned with "
            "established medical references (WHO Model List of Essential Medicines, FDA/DailyMed "
            "prescribing information, British National Formulary, and MedlinePlus).\n"
            "SAFETY RULES:\n"
            "1. Do NOT invent unverified indications or encourage self-medication with prescription drugs.\n"
            "2. Do NOT prescribe exact individualized doses—describe general adult/standard reference "
            "considerations and emphasize following a doctor or pharmacist's prescription.\n"
            "3. If Patient Context mentions allergies or current medications, explicitly check for "
            "potential drug-drug or allergy interactions and highlight any cautions.\n"
            "4. Organize your response under clear headings:\n"
            "   - Medicine Overview (Generic Name, Drug Class & Mechanism)\n"
            "   - Approved / Common Uses\n"
            "   - General Administration & Precautions\n"
            "   - Side Effects (Common vs. Serious — When to Seek Care)\n"
            "   - Interactions & Contraindications\n"
            "   - Reference Disclaimer (Verify with a licensed pharmacist or physician)\n"
            + _language_directive(language)
        )

        lines = [f"Medicine / Active Ingredient Query: {medicine_name.strip()}"]
        if extra_question.strip():
            lines.append(f"Specific Question: {extra_question.strip()}")
        if patient_context.strip():
            lines.append(f"Patient Context (Check Allergies/Interactions): {patient_context.strip()}")

        prompt = "\n".join(lines)

        def _run() -> str:
            resp = client.models.generate_content(
                model=self.model_name,
                contents=prompt,
                config=types.GenerateContentConfig(system_instruction=system_instruction),
            )
            return resp.text or ""

        return self._call_with_retry(_run)

    # ------------------------------------------------------------------
    # Module 4: AI Health Assistant (Multi-turn Open-Ended Q&A)
    # ------------------------------------------------------------------
    def create_assistant_chat(
        self,
        language: str = "English",
        patient_context: str = "",
    ):
        """Create a stateful Gemini chat session for open-ended health Q&A."""
        client = self._get_client()
        context_block = (
            f"\nActive Patient Context (use sensitively for personalized educational relevance): {patient_context}"
            if patient_context.strip()
            else ""
        )
        system_instruction = (
            "You are MEDINOVA AI, a compassionate, evidence-informed healthcare education assistant. "
            "Answer open-ended health, wellness, nutrition, preventive care, lab-literacy, and medical "
            "terminology questions clearly and responsibly.\n"
            "SAFETY RULES:\n"
            "- Clarify that your guidance is educational and does not replace a licensed clinician.\n"
            "- Never fabricate clinical guidelines or statistics.\n"
            "- For urgent or emergency symptoms, direct the user to immediate medical care.\n"
            + _language_directive(language)
            + context_block
        )
        return client.chats.create(
            model=self.model_name,
            config=types.GenerateContentConfig(system_instruction=system_instruction),
        )

    def send_chat_message(self, chat_session, user_message: str) -> str:
        """Send a message to an active Gemini chat session with retry/error handling."""
        if not user_message.strip():
            raise GeminiServiceError("Please enter a question before sending.")

        def _run() -> str:
            resp = chat_session.send_message(user_message.strip())
            return resp.text or ""

        return self._call_with_retry(_run)

    # ------------------------------------------------------------------
    # Module 5: Medical PDF Analyzer
    # ------------------------------------------------------------------
    def analyze_medical_pdf_text(
        self,
        extracted_text: str,
        file_name: str,
        language: str = "English",
        patient_context: str = "",
        custom_question: str = "",
    ) -> str:
        client = self._get_client()
        system_instruction = (
            "You are MEDINOVA AI's Medical Document & Lab Report Explainer. "
            "You help patients understand text extracted from medical PDFs (lab reports, discharge "
            "summaries, imaging reports, prescriptions).\n"
            "SAFETY RULES:\n"
            "1. Only summarize and explain what is actually present in the provided document text. "
            "Never invent lab numbers, dates, or diagnoses.\n"
            "2. Highlight any values explicitly marked High/Low/Abnormal in the report and explain "
            "what those markers generally measure in plain language.\n"
            "3. Remind the patient to review all findings with their ordering physician.\n"
            "4. Structure the analysis cleanly:\n"
            "   - Document Summary\n"
            "   - Key Findings & Values Explained\n"
            "   - Medications / Next Steps Mentioned in Document\n"
            "   - Suggested Questions for Your Doctor\n"
            + _language_directive(language)
        )

        clipped_text = extracted_text[:28000]
        prompt_parts = [
            f"Uploaded File: {file_name}",
            f"Patient Context: {patient_context.strip() or 'Not provided'}",
        ]
        if custom_question.strip():
            prompt_parts.append(f"User's Specific Question About Document: {custom_question.strip()}")
        prompt_parts.append(f"Extracted Document Text:\n{clipped_text}")

        prompt = "\n\n".join(prompt_parts)

        def _run() -> str:
            resp = client.models.generate_content(
                model=self.model_name,
                contents=prompt,
                config=types.GenerateContentConfig(system_instruction=system_instruction),
            )
            return resp.text or ""

        return self._call_with_retry(_run)
