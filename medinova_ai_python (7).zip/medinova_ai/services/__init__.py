"""Core services package for MEDINOVA AI."""
