"""Local JSON storage and clinical context formatting for Patient Profile."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Optional


@dataclass
class PatientProfile:
    full_name: str = ""
    age: str = ""
    sex: str = "Prefer not to say"
    blood_group: str = "Unknown"
    height_cm: str = ""
    weight_kg: str = ""
    allergies: str = ""
    chronic_conditions: str = ""
    current_medications: str = ""
    emergency_contact: str = ""
    preferred_language: str = "English"

    def calculate_bmi(self) -> Optional[float]:
        try:
            height_m = float(self.height_cm) / 100.0
            weight = float(self.weight_kg)
            if height_m <= 0 or weight <= 0:
                return None
            return round(weight / (height_m * height_m), 1)
        except (TypeError, ValueError):
            return None

    def to_clinical_context(self) -> str:
        """Format non-identifying clinical metadata for AI prompt grounding."""
        parts = []
        if self.age.strip():
            parts.append(f"Age: {self.age.strip()}")
        if self.sex and self.sex != "Prefer not to say":
            parts.append(f"Biological Sex: {self.sex}")
        if self.blood_group and self.blood_group != "Unknown":
            parts.append(f"Blood Group: {self.blood_group}")
        bmi = self.calculate_bmi()
        if bmi is not None:
            parts.append(f"BMI: {bmi} kg/m^2")
        if self.allergies.strip():
            parts.append(f"Known Allergies: {self.allergies.strip()}")
        if self.chronic_conditions.strip():
            parts.append(f"Existing Conditions: {self.chronic_conditions.strip()}")
        if self.current_medications.strip():
            parts.append(f"Current Medications: {self.current_medications.strip()}")

        if not parts:
            return "No patient clinical context provided."
        return " | ".join(parts)


class ProfileStore:
    """Persists and loads PatientProfile from a local JSON file."""

    def __init__(self, file_path: Optional[Path] = None) -> None:
        base_dir = Path(__file__).resolve().parent.parent
        self.file_path = file_path or (base_dir / "data" / "patient_profile.json")

    def load(self) -> PatientProfile:
        if not self.file_path.exists():
            return PatientProfile()
        try:
            raw = json.loads(self.file_path.read_text(encoding="utf-8"))
            valid_fields = PatientProfile.__dataclass_fields__.keys()
            filtered = {k: str(v) for k, v in raw.items() if k in valid_fields and v is not None}
            return PatientProfile(**filtered)
        except (OSError, json.JSONDecodeError, TypeError):
            return PatientProfile()

    def save(self, profile: PatientProfile) -> None:
        self.file_path.parent.mkdir(parents=True, exist_ok=True)
        self.file_path.write_text(
            json.dumps(asdict(profile), indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
