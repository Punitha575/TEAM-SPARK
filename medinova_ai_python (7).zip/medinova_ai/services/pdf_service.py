"""PyMuPDF-based medical PDF text extraction service."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List

import fitz  # PyMuPDF


class PDFExtractionError(Exception):
    """Raised when a medical PDF cannot be read or contains no extractable text."""


@dataclass
class ExtractedPDF:
    file_name: str
    page_count: int
    total_characters: int
    full_text: str
    page_texts: List[str]
    truncated_for_ai: bool = False


def extract_medical_pdf(file_path: str | Path, max_ai_chars: int = 28000) -> ExtractedPDF:
    """
    Extract readable text from an uploaded medical PDF using PyMuPDF (fitz).

    Args:
        file_path: Path to the .pdf file.
        max_ai_chars: Safety cap for prompt length if a report is very large.

    Returns:
        ExtractedPDF containing page counts and cleaned text.
    """
    path = Path(file_path)
    if not path.exists() or not path.is_file():
        raise PDFExtractionError("The selected PDF file could not be found.")

    if path.suffix.lower() != ".pdf":
        raise PDFExtractionError("Please select a valid .pdf document.")

    try:
        doc = fitz.open(str(path))
    except Exception as exc:
        raise PDFExtractionError(f"Unable to open PDF file: {exc}") from exc

    try:
        if doc.is_encrypted:
            raise PDFExtractionError(
                "This PDF is password-protected or encrypted. Please unlock it before uploading."
            )

        page_texts: List[str] = []
        for idx, page in enumerate(doc, start=1):
            # sort=True preserves natural reading order across multi-column lab tables
            raw_text = page.get_text("text", sort=True) or ""
            cleaned = "\n".join(line.rstrip() for line in raw_text.splitlines()).strip()
            if cleaned:
                page_texts.append(f"--- Page {idx} ---\n{cleaned}")

        combined = "\n\n".join(page_texts).strip()
        if not combined:
            raise PDFExtractionError(
                "No selectable text was found in this PDF. It appears to be a scanned image. "
                "Please upload a text-based medical PDF or run OCR on it first."
            )

        truncated = len(combined) > max_ai_chars
        return ExtractedPDF(
            file_name=path.name,
            page_count=len(doc),
            total_characters=len(combined),
            full_text=combined,
            page_texts=page_texts,
            truncated_for_ai=truncated,
        )
    finally:
        doc.close()
